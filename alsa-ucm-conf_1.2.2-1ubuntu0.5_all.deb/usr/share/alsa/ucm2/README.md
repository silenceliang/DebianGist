Use Case Configuration files
----------------------------

Library directories:

  platforms/
  codecs/
  dsps/

Those directories are not inspected for the list of
available UCM configurations. They contain files
included from other UCMs.

Syntax, value names
-------------------

https://git.alsa-project.org/?p=alsa-lib.git;a=blob;f=include/use-case.h
